package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements.Departement_Gestion_groups;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements.Departement_Mecanique;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements.Departement_info_groups;
import com.example.gest_infos.gestioninformation.R;

public class choice_field extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_field);
    }

    public void Dep_Mecanique(View view) {
        startActivity(new Intent(choice_field.this, Departement_Mecanique.class));

    }

    public void Dep_Gestion(View view) {
        startActivity(new Intent(choice_field.this, Departement_Gestion_groups.class));

    }

    public void Dep_informatique(View view) {
        startActivity(new Intent(choice_field.this, Departement_info_groups.class));

    }
}
