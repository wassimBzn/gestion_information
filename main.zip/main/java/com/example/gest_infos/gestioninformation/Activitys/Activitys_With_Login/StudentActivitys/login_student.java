package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.R;

public class login_student extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_student);
    }

    public void Signin_etudiant_btn(View view) {
        startActivity(new Intent(login_student.this,acceuil_student.class));
    }
}
