package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.gest_infos.gestioninformation.Classes_no_activitys.Matiere;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.student;
import com.example.gest_infos.gestioninformation.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class chose_matiere extends AppCompatActivity {
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chose_matiere);
        progressDialog = new ProgressDialog(this);
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_Matiere = database.getReference("Matiere");
        final ListView list=(ListView)findViewById(R.id.chose_matiere_liste_view);
        final ArrayList<Matiere> res_list=new ArrayList<>();
        final MyMatiereAdabter adapter=new MyMatiereAdabter(res_list);
        myRef_Matiere.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                progressDialog.dismiss();
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    res_list.add(new Matiere(child.child("id_Matiere").getValue().toString(),
                            child.child("libelle").getValue().toString()));
                }
                list.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
    public class MyMatiereAdabter extends BaseAdapter {
        ArrayList<Matiere> items_ListView = new ArrayList<>();

        MyMatiereAdabter(ArrayList<Matiere> items_ListView) {
            this.items_ListView = items_ListView;
        }

        @Override
        public int getCount() {
            return items_ListView.size();
        }

        @Override
        public Object getItem(int i) {
            return items_ListView.get(i).getMatier_Id();
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater li = getLayoutInflater();
            View view1 = li.inflate(R.layout.row_chose_matiere, null);
            final TextView Nom_Matiere = (TextView) view1.findViewById(R.id.Nom_Matiere);
            final TextView cin = (TextView) view1.findViewById(R.id.textView2);
            final TextView idMatiere = (TextView) view1.findViewById(R.id.textView3);
            final TextView group = (TextView) view1.findViewById(R.id.group);

           Bundle b=getIntent().getExtras();

           idMatiere.setText(items_ListView.get(i).getMatier_Id()); 
            group.setText(b.getString("groupe"));
            cin.setText(b.getString("Cin"));
            Log.v("grou9","3"+group.getText().toString());
             Nom_Matiere.setText(items_ListView.get(i).getLibelle_Matiere());
            Button Confirm_absance_final=(Button)view1.findViewById(R.id.Confirm_absance_final);
            Confirm_absance_final.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(chose_matiere.this,confirm_absance.class);
                    intent.putExtra("nom_matiere",Nom_Matiere.getText().toString());
                    intent.putExtra("Cin",cin.getText().toString());
                    intent.putExtra("groupe",group.getText().toString());
                    intent.putExtra("id_matiere",idMatiere.getText().toString());
                    startActivity(intent);
                    Log.v("grou9","4"+group.getText().toString());



                }
            });

            return view1;
        }

    }
}
