package com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.gest_infos.gestioninformation.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class Advanced_search_Activity extends AppCompatActivity {
    private ProgressDialog progressDialog;
    String ens_key;String fil_key;String niv_key;String Mat_key;
    EditText txtEns_Name;
    EditText txtMat_Name;
    EditText txtfiliere_Name;
    EditText txtNiv_Name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_search_);

        final   Spinner Recherche_Advanced_enseignant_spinner=(Spinner)findViewById(R.id.Recherche_Advanced_enseignant_spinner);
        final   Spinner Recherche_Advanced_Matiere_spinner=(Spinner)findViewById(R.id.Recherche_Advanced_Matiere_spinner);
        final   Spinner Recherche_Advanced_Fieliere_spinner=(Spinner)findViewById(R.id.Recherche_Advanced_Fieliere_spinner);
        final   Spinner Recherche_Advanced_niveau_spinner=(Spinner)findViewById(R.id.Recherche_Advanced_niveau_spinner);

        final  Spinner Recherche_Advanced_enseignant_spinner_key=(Spinner)findViewById(R.id.Recherche_Advanced_enseignant_spinner_key);
        final  Spinner Recherche_Advanced_Matiere_spinner_key=(Spinner)findViewById(R.id.Recherche_Advanced_Matiere_spinner_key);
        final  Spinner Recherche_Advanced_Fieliere_spinner_key=(Spinner)findViewById(R.id.Recherche_Advanced_Fieliere_spinner_key);
        final  Spinner Recherche_Advanced_niveau_spinner_key=(Spinner)findViewById(R.id.Recherche_Advanced_niveau_spinner_key);
        progressDialog = new ProgressDialog(this);
        final ArrayList<String> values_Enseignant=new ArrayList<>();
        values_Enseignant.add("Enter Enseignant Name");

        final ArrayList<String> keys_Enseignant=new ArrayList<>();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_enseignant = database.getReference("Enseignant");
        final  ArrayAdapter<String> adapter1=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values_Enseignant);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final  ArrayAdapter<String> adapter2=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,keys_Enseignant);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        ens_key="";
        fil_key="";
        niv_key="";
        Mat_key="";


        myRef_enseignant.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    progressDialog.dismiss();
                    values_Enseignant.add(child.child("Full_Name").getValue().toString());
                    keys_Enseignant.add(child.child("id_enseignant").getValue().toString());

                    Log.d("7aaa",""+child.child("operation_category").getValue());
                    Recherche_Advanced_enseignant_spinner.setAdapter(adapter1);
                    Recherche_Advanced_enseignant_spinner_key.setAdapter(adapter2);

                }
                ens_key=Recherche_Advanced_enseignant_spinner.getSelectedItem().toString();
                Log.v("spinner",ens_key);
        }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
/*******************************************************************************/
        final ArrayList<String> values_Matiere=new ArrayList<>();

        values_Matiere.add("Enter le Nom de la matiere");

        final ArrayList<String> keys_Matiere=new ArrayList<>();
        DatabaseReference myRef_matiere = database.getReference("Matiere");
        final  ArrayAdapter<String> adapter3=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values_Matiere);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final  ArrayAdapter<String> adapter4=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,keys_Matiere);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        myRef_matiere.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    values_Matiere.add(child.child("libelle").getValue().toString());
                    keys_Matiere.add(child.child("id_Matiere").getValue().toString());

                    Log.d("7aaa",""+child.child("operation_category").getValue());
                    progressDialog.dismiss();
                    Recherche_Advanced_Matiere_spinner.setAdapter(adapter3);
                    Recherche_Advanced_Matiere_spinner_key.setAdapter(adapter4);
                  Mat_key=Recherche_Advanced_Matiere_spinner.getSelectedItem().toString();
                }



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
/*************************************************************************************************************************/
        final ArrayList<String> values_Filiere=new ArrayList<>();

        values_Filiere.add("Enter la Filiere");

        final ArrayList<String> keys_Filiere=new ArrayList<>();
        DatabaseReference myRef_Filiere = database.getReference("Filiere");
        final  ArrayAdapter<String> adapter5=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values_Filiere);
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final  ArrayAdapter<String> adapter6=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,keys_Filiere);
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        myRef_Filiere.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    values_Filiere.add(child.child("Nom_Filiere").getValue().toString());
//                    keys_Filiere.add(child.child("id_Filiere").getValue().toString());
                    Recherche_Advanced_Fieliere_spinner.setAdapter(adapter5);
                    Recherche_Advanced_Fieliere_spinner_key.setAdapter(adapter6);
                    fil_key=Recherche_Advanced_Fieliere_spinner.getSelectedItem().toString();
                }




            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

 /*************************************************************************************************************************/
        final ArrayList<String> values_Niveau=new ArrayList<>();

        values_Niveau.add("Enter le Niveau");

        final ArrayList<String> keys_Niveau=new ArrayList<>();
        DatabaseReference myRef_Niveau = database.getReference("Niveau");
        final  ArrayAdapter<String> adapter7=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values_Niveau);
        adapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final  ArrayAdapter<String> adapter8=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,keys_Niveau);
        adapter8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        myRef_Niveau.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    values_Niveau.add(child.child("Niv").getValue().toString());
                    keys_Niveau.add(child.child("id_Niveau").getValue().toString());


                    Recherche_Advanced_niveau_spinner.setAdapter(adapter7);
                    niv_key=Recherche_Advanced_niveau_spinner.getSelectedItem().toString();
                    Log.d("niv_key",niv_key);
                    Recherche_Advanced_niveau_spinner_key.setAdapter(adapter8);
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        int a=(Integer)Recherche_Advanced_enseignant_spinner.getSelectedItemPosition();
        Log.d("fds",""+a);



        /********************another way********************************************************************************/
        txtEns_Name=(EditText) findViewById(R.id.txtEns_Name);
        txtMat_Name=(EditText)findViewById(R.id.txtMat_Name);
        txtfiliere_Name=(EditText)findViewById(R.id.txtfiliere_Name);
        txtNiv_Name=(EditText)findViewById(R.id.txtNiv_Name);



        /*************************************************************************************************/

    }


    public void Recherche_Advanced_research_btn(View view) {
        Intent intent =new Intent(Advanced_search_Activity.this,Result_Research_Activity.class);
        if (txtEns_Name.getText().toString().isEmpty()&&
                txtMat_Name.getText().toString().isEmpty()&&
                txtfiliere_Name.getText().toString().isEmpty()&&
                txtNiv_Name.getText().toString().isEmpty()
        )
        {
            AlertDialog.Builder alert= new AlertDialog.Builder(Advanced_search_Activity.this);
            alert.setMessage("No Data Found ! Go Back And re-enter your data ")
                    .setIcon(android.R.drawable.stat_notify_error)
                    .setTitle("Alert")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                         }
                    }).show();
        }else{
            if (txtEns_Name.getText().toString().isEmpty())
                txtEns_Name.setText("`");
              if( txtMat_Name.getText().toString().isEmpty())
                  txtMat_Name.setText("`");
              if(txtfiliere_Name.getText().toString().isEmpty())
                  txtfiliere_Name.setText("`");
            if(txtNiv_Name.getText().toString().isEmpty())
                txtNiv_Name.setText("`");
            intent.putExtra("key_Enseignant",txtEns_Name.getText().toString());
        intent.putExtra("key_Filiere",txtMat_Name.getText().toString());
        intent.putExtra("key_Matiere",txtfiliere_Name.getText().toString());
        intent.putExtra("key_Niveau",txtNiv_Name.getText().toString());
        intent.putExtra("Type",2);
        Log.d("eeeeeeeeeee","ALl Done!.../" );
        startActivity(intent);
     }
    }
}
