package com.example.gest_infos.gestioninformation.Activitys.Generic_Activitys;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys.Emploi;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys.Recherche_Cour_Choices;
import com.example.gest_infos.gestioninformation.R;

public class Accueil_NoLogin_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil__no_login_);
    }

    public void Emploi_Choice_btn(View view) {
        startActivity(new Intent(Accueil_NoLogin_Activity.this, Emploi.class));

    }

    public void Notes_btn_Choice(View view) {
    }

    public void Cours_btn_choice(View view) {
        startActivity(new Intent(Accueil_NoLogin_Activity.this, Recherche_Cour_Choices.class));
    }
}


