package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys.AdminLogin_Activity;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys.Admin_choice_list;
import com.example.gest_infos.gestioninformation.R;

public class Accueil_prof extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil_prof);
    }

    public void See_All_Students(View view) {
        startActivity(new Intent(Accueil_prof.this,choice_field.class));

    }
}
