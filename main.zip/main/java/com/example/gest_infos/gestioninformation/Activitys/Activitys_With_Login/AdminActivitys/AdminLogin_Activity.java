package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.R;

public class AdminLogin_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login_);
    }

    public void Signin_Admin_btn(View view) {
        startActivity(new Intent(AdminLogin_Activity.this,Admin_choice_list.class));
    }
}
