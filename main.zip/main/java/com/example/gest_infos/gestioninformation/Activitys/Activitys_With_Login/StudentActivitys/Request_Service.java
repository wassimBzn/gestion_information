package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant.Accueil_prof;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant.choice_field;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant.confirm_absance;
import com.example.gest_infos.gestioninformation.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class Request_Service extends AppCompatActivity {
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request__service);

        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals("Home")){
                    startActivity(new Intent(getBaseContext(),acceuil_student.class));
                }else if (menuItem.getTitle().equals("Service")){
                    startActivity(new Intent(getBaseContext(),Request_Service.class));
                }else if (menuItem.getTitle().equals("Absence")){
                    startActivity(new Intent(getBaseContext(),seeAllAbsStudents.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });
    }

    public void service_request(View view) {
        progressDialog = new ProgressDialog(this);
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        Random r = new Random();
        EditText Name_service=(EditText)findViewById(R.id.Name_service);
        EditText Email_service=(EditText)findViewById(R.id.Email_service);
        EditText Request_service=(EditText)findViewById(R.id.Request_service);
        int min = 80000000;
        int max = 900000000;
        int i1 = r.nextInt(max - min + 1) + min;
        DatabaseReference myRef=database.getReference("Service_Request/"+i1);
        myRef.child("id_service").setValue(i1);
        myRef.child("Name_service").setValue(Name_service.getText().toString());
        myRef.child("Email_service").setValue(Email_service.getText().toString());
        myRef.child("Request_service").setValue(Request_service.getText().toString());
        Toast.makeText(Request_Service.this,"service envoyer avec succès !",Toast.LENGTH_LONG).show();
        startActivity(new Intent(Request_Service.this,acceuil_student.class));

    }
}
