package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant.see_All_students;
import com.example.gest_infos.gestioninformation.R;

public class Departement_Gestion_groups extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_departement__gestion_groups);
    }

    public void TV5(View view) {
    }

    public void CI5(View view) {
    }

    public void GC5(View view) {
    }

    public void CI3(View view) {
    }

    public void GC3(View view) {
    }

    public void MK3(View view) {
    }

    public void MK2(View view) {
         Intent intent=new Intent(Departement_Gestion_groups.this,see_All_students.class);
            intent.putExtra("group","G1");
            startActivity(intent);
    }

    public void MK1(View view) {
    }


    public void AA3(View view) {
    }

    public void AA2(View view) {
    }

    public void AA1(View view) {
    }

    public void TV3(View view) {
    }
}

