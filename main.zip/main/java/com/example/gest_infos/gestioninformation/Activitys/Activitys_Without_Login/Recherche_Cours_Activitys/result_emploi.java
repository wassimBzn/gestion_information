package com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys;

import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.Request_Service;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.acceuil_student;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.seeAllAbsStudents;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.visualise_note;
import com.example.gest_infos.gestioninformation.Activitys.Generic_Activitys.Accueil_NoLogin_Activity;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class result_emploi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_emploi);
        WebView web=(WebView)findViewById(R.id.web);
        web.setWebViewClient(new WebViewClient());
        web.getSettings().setJavaScriptEnabled(true);
        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals("Home")){
                    startActivity(new Intent(getBaseContext(),acceuil_student.class));
                }else if (menuItem.getTitle().equals("Autre service")){
                    startActivity(new Intent(getBaseContext(),Accueil_NoLogin_Activity.class));
                }else if (menuItem.getTitle().equals("Absence")){
                    startActivity(new Intent(getBaseContext(),seeAllAbsStudents.class));
                }else if (menuItem.getTitle().equals("Demander service")){
                    startActivity(new Intent(getBaseContext(),Request_Service.class));
                }else if (menuItem.getTitle().equals("Notes")){
                    startActivity(new Intent(getBaseContext(),visualise_note.class));
                }else if (menuItem.getTitle().equals("deconnecter")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });
        Bundle b=getIntent().getExtras();

        String res=b.getString("res");
        Log.v("loggg",res);
        if (res.equals("gestion")){
            web.loadUrl("https://drive.google.com/open?id=1h0YOOkH7q5hb4NBuC6Urs7ccd28lUbMw");
        }else if (res.equals("ti")){
            web.loadUrl("https://drive.google.com/open?id=1621BiuIm7f2jstvC6c3_Sl_rPUPhf644");
        }else if (res.equals("gm")){
            web.loadUrl("https://drive.google.com/open?id=1zzh75b6C9fWtO0kGA4D9ufQ5kY_eImQE");
        }else if (res.equals("ge")){
            web.loadUrl("https://drive.google.com/open?id=1OjEKhjYHOkeobN2r7FRXG96u6-DqN685");
        }
    }
}
