package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.gest_infos.gestioninformation.R;

public class Departement_Mecanique extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_departement__mecanique);
    }
}
