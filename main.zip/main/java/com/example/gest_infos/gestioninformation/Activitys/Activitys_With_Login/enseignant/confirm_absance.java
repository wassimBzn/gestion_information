package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.gest_infos.gestioninformation.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

public class confirm_absance extends AppCompatActivity {
    String Cin;String nom_matiere;String date;String idMatiere;String groupe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_absance);
        Bundle b=getIntent().getExtras();
         Cin=b.getString("Cin");
         groupe=b.getString("groupe");

         idMatiere=b.getString("id_matiere");
         nom_matiere=b.getString("nom_matiere");
       Log.v("aaaaaaaa",""+Cin+","+nom_matiere);
        DatePicker datePicker=(DatePicker)findViewById(R.id.datePicker);
        date=datePicker.getDayOfMonth()+"/"+datePicker.getMonth()+"/"+datePicker.getYear();
    }

    public void Confirm_Absance_Final(View view) {
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference myRef_student = database.getReference("Etudiant").child("Groupe").child(groupe);
        Random r = new Random();
        DatabaseReference myRef=database.getReference();
        int min = 1;
        int max = 80000000;
        int i1 = r.nextInt(max - min + 1) + min;
        Log.v("nom",nom_matiere+"-"+nom_matiere.length());
        Log.v("nom","_");
        Log.v("nom",groupe);

        Log.v("grou9","5"+groupe);


        if (nom_matiere.equals("english")){
            Log.v("grou9","enslish-"+groupe);
            myRef = database.getReference("Etudiant/Groupe/"+groupe+"/"+Cin+"/Absance/english/"+i1);
           //myRef = database.getReference("Etudiant").child("Groupe").child(groupe).child(Cin).child("Absance").child("english").child(""+i1);
        }else if (nom_matiere.equals("programmation")){
            Log.v("grou9","enslish-"+groupe);
             //myRef = database.getReference("Etudiant/Groupe/"+groupe+"/"+Cin+"/Absance/programmation/"+i1);
            myRef = database.getReference("Etudiant").child("Groupe").child(groupe).child(Cin).child("Absance").child("programmation").child(""+i1);

        }
        Log.v("aaaaa","done");
        myRef.child("id_Absance").setValue(i1);
        Log.v("aaaaa","done2");
        myRef.child("date_absance").setValue(date);Log.v("aaaaa","done3");
        myRef.child("Matiere").setValue(nom_matiere);Log.v("aaaaa","done4");
        myRef.child("id_Matiere").setValue(idMatiere);Log.v("aaaaa","done5");
        Toast.makeText(confirm_absance.this,"Absance ajoutée avec succès!",Toast.LENGTH_LONG).show();
        startActivity(new Intent(confirm_absance.this,choice_field.class));
        Log.v("aaaaa","done7");
        Log.v("grou9","6"+groupe);
    }
}
