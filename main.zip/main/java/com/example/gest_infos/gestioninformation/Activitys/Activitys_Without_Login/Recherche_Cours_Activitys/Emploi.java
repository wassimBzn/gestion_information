package com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys;

import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;

import com.example.gest_infos.gestioninformation.R;

import java.util.LinkedList;

public class Emploi extends AppCompatActivity {
    int i ;int size ;
    ImageView imgSwitch_emp;
    Button next;
    Button previous;
    LinkedList<Integer> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emploi);
        i=0;size=0;
        imgSwitch_emp=(ImageView) findViewById(R.id.imgSwitch_emp);
          next=(Button)findViewById(R.id.next_btn_emploi);
        previous=(Button)findViewById(R.id.Previous_btn_emploi);

        list=new LinkedList<>();

        list.add(R.drawable.aa2);size++;
        list.add(R.drawable.aa3);size++;
        list.add(R.drawable.aa4);size++;
        list.add(R.drawable.aa5);size++;
        Log.v("hhhhhhhh","emploi");
    }

    public void previous_btn(View view) {

        if (i<=0){
            i=size;
        }
        imgSwitch_emp.setImageResource(list.get(i));
        i--;

    }

    public void next_btn(View view) {
    if (i>=size){
        i=0;
    }
        imgSwitch_emp.setImageResource(list.get(i));
    i++;
    }
}
