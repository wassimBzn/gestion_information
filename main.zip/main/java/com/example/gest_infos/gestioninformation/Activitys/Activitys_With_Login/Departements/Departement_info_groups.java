package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant.see_All_students;
import com.example.gest_infos.gestioninformation.R;

public class Departement_info_groups extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_departement_info_groups);
    }



    public void TI1(View view) {
        Intent intent=new Intent(Departement_info_groups.this,see_All_students.class);
        intent.putExtra("group","TI1");
        startActivity(intent);

    }

    public void TI2(View view) {
    }

    public void TI3(View view) {
    }

    public void TI4(View view) {
    }

    public void TI5(View view) {
    }

    public void TI6(View view) {
    }

    public void DSI3(View view) {
    }

    public void RSI3(View view) {
    }

    public void MDW3(View view) {
    }

    public void DSI5(View view) {
    }

    public void RSI5(View view) {
    }
    public void MDW5(View view) {
    }
}
