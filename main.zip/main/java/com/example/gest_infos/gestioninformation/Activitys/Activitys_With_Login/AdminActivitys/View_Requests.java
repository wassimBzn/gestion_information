package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant.see_All_students;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Service;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.student;
import com.example.gest_infos.gestioninformation.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class View_Requests extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view__requests);
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_student = database.getReference("Service_Request");
        final ListView list = (ListView) findViewById(R.id.list_service);
        final ArrayList<Service> res_list = new ArrayList<>();
         final MyServiceAdabter adapter=new MyServiceAdabter(res_list);
         myRef_student.addValueEventListener(new ValueEventListener() {
             @Override
             public void onDataChange(DataSnapshot dataSnapshot) {
                 for (DataSnapshot child : dataSnapshot.getChildren()){
                     res_list.add(new Service(child.child("id_service").getValue().toString(),
                             child.child("Name_service").getValue().toString(),
                             child.child("Email_service").getValue().toString(),
                             child.child("Request_service").getValue().toString()) );
                 }
                 list.setAdapter(adapter);
                 adapter.notifyDataSetChanged();
             }

             @Override
             public void onCancelled(DatabaseError databaseError) {

             }
         });


    }


    public class MyServiceAdabter extends BaseAdapter {
        ArrayList<Service> items_ListView = new ArrayList<>();

        MyServiceAdabter(ArrayList<Service> items_ListView) {
            this.items_ListView = items_ListView;
        }

        @Override
        public int getCount() {
            return items_ListView.size();
        }

        @Override
        public Object getItem(int i) {
            return items_ListView.get(i).getId_service();
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater li = getLayoutInflater();

            View view1 = li.inflate(R.layout.row_service, null);
            TextView Name_service = (TextView) view1.findViewById(R.id.Name_service);
            TextView Email_service = (TextView) view1.findViewById(R.id.Email_service);
            TextView Request_service = (TextView) view1.findViewById(R.id.Request_service);


            Name_service.setText("Le nom du l'etudient: " + items_ListView.get(i).getName_service());
            Email_service.setText("Email de L'étudiant: " + items_ListView.get(i).getEmail_service());
            Request_service.setText("le demande: " + items_ListView.get(i).getRequest_Service());
            return view1;
        }
    }
}