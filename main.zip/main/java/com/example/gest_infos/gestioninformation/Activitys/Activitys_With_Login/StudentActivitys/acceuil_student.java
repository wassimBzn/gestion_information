package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys;

import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import io.github.yavski.fabspeeddial.FabSpeedDial;

import com.example.gest_infos.gestioninformation.MainActivity;
import com.example.gest_infos.gestioninformation.R;

public class acceuil_student extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acceuil_student);

        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals("Home")){
                    startActivity(new Intent(getBaseContext(),acceuil_student.class));
                }else if (menuItem.getTitle().equals("Service")){
                    startActivity(new Intent(getBaseContext(),Request_Service.class));
                }else if (menuItem.getTitle().equals("Absence")){
                    startActivity(new Intent(getBaseContext(),seeAllAbsStudents.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });
    }

    public void seeAbsStudents(View view) {
        startActivity(new Intent(acceuil_student.this,seeAllAbsStudents.class));

    }

    public void Request_service(View view) {
        startActivity(new Intent(acceuil_student.this,Request_Service.class));

    }

    public void disconnect_student(View view) {
        startActivity(new Intent(acceuil_student.this,MainActivity.class));

    }
}
