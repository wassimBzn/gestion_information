package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys;

import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.CalendarView;
import android.widget.TextView;

import com.example.gest_infos.gestioninformation.R;

import java.util.Calendar;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class detail_abs_students extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_abs_students);
        Bundle b=getIntent().getExtras();
        int nbAbsance=b.getInt("nbabsance");
        String Etat=b.getString("Etat");
        String date_abs=b.getString("date_abs");
        String Matiere_abs=b.getString("Matiere_abs");

        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals("Home")){
                    startActivity(new Intent(getBaseContext(),acceuil_student.class));
                }else if (menuItem.getTitle().equals("Service")){
                    startActivity(new Intent(getBaseContext(),Request_Service.class));
                }else if (menuItem.getTitle().equals("Absence")){
                    startActivity(new Intent(getBaseContext(),seeAllAbsStudents.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });

        CalendarView calendarView=(CalendarView)findViewById(R.id.calendarView);
        TextView nbabsance=(TextView)findViewById(R.id.nbabsance);
        TextView EtatText=(TextView)findViewById(R.id.Etat);
        TextView date_absText=(TextView)findViewById(R.id.date_abs);
        nbabsance.setText("Nombre D'absance: "+nbAbsance);
        EtatText.setText("Etat"+Etat);
        date_absText.setText("Date Abs: "+date_abs);
        String date = date_abs;
        String parts[] = date.split("/");

        int day = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        int year = Integer.parseInt(parts[2]);

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);

        long milliTime = calendar.getTimeInMillis();
        calendarView.setDate (milliTime, true, true);

    }
}
