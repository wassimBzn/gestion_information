package com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.R;

public class Recherche_Cour_Choices extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recherche__cour__choices);
    }

    public void Recherche_Symple_Btn(View view) {
        startActivity(new Intent(Recherche_Cour_Choices.this,Simple_Search_Activity.class));
    }

    public void Recherche_Advanced_Btn(View view) {
        startActivity(new Intent(Recherche_Cour_Choices.this,Advanced_search_Activity.class));

    }
}
