package com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys;

import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.Request_Service;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.acceuil_student;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.seeAllAbsStudents;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.visualise_note;
import com.example.gest_infos.gestioninformation.Activitys.Generic_Activitys.Accueil_NoLogin_Activity;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class Recherche_Cour_Choices extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recherche__cour__choices);
        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals("Home")){
                    startActivity(new Intent(getBaseContext(),acceuil_student.class));
                }else if (menuItem.getTitle().equals("Autre service")){
                    startActivity(new Intent(getBaseContext(),Accueil_NoLogin_Activity.class));
                }else if (menuItem.getTitle().equals("Absence")){
                    startActivity(new Intent(getBaseContext(),seeAllAbsStudents.class));
                }else if (menuItem.getTitle().equals("Demander service")){
                    startActivity(new Intent(getBaseContext(),Request_Service.class));
                }else if (menuItem.getTitle().equals("Notes")){
                    startActivity(new Intent(getBaseContext(),visualise_note.class));
                }else if (menuItem.getTitle().equals("deconnecter")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });
    }

    public void Recherche_Symple_Btn(View view) {
        startActivity(new Intent(Recherche_Cour_Choices.this,Simple_Search_Activity.class));
    }

    public void Recherche_Advanced_Btn(View view) {
        startActivity(new Intent(Recherche_Cour_Choices.this,Advanced_search_Activity.class));

    }
}
