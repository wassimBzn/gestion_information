package com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gest_infos.gestioninformation.Classes_no_activitys.Cours;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Enseignant;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Filiere;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Matiere;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Niveau;
import com.example.gest_infos.gestioninformation.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class Result_Research_Activity extends AppCompatActivity {
    private ProgressDialog progressDialog;
    int type ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result__research_);
         final String ens_key ;   final String fil_key ;
         final String niv_key ;   final String Mat_key ;
         final String Name_course  ;

        progressDialog = new ProgressDialog(this);

        final Spinner spinner_result_aux=(Spinner)findViewById(R.id.spinner_result_aux);
        final ArrayList<String> spinner_result=new ArrayList<>();
        final ArrayAdapter<String> adapter1=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,spinner_result);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_cours = database.getReference("Cours");
        final ListView listView_result=(ListView)findViewById(R.id.Result_Research_listView);
        final ArrayList<Cours> res_list=new ArrayList<>();
        final MyCoursAdabter adapter=new MyCoursAdabter (res_list);
        /*progressDialog.setMessage("Please wait...");
        progressDialog.show();*/

        Bundle b=getIntent().getExtras();
        type=b.getInt("Type");
        Log.d("Name_course",""+type);
        Log.d("Name_course",""+type);
        if (type==1){
            Log.d("Name_course",""+type);
            Name_course=b.getString("Name_Cours");
            spinner_result.add(Name_course);
            myRef_cours.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot child : dataSnapshot.getChildren()){
                        if (child.child("Name_Cours").getValue().toString().contains(Name_course)){
                            res_list.add(new Cours(child.child("id_cours").getValue().toString(),
                                    child.child("Name_Cours").getValue().toString(),
                                    new Enseignant(child.child("Enseignant").child("Full_Name").getValue().toString()),
                                    new Matiere(child.child("Matiere").child("id_Matiere").getValue().toString()
                                            ,child.child("Matiere").child("libelle").getValue().toString()),
                                    new Niveau(child.child("Niveau").child("Niv").getValue().toString()),
                                    new Filiere(child.child("Filiere").child("Nom_Filiere").getValue().toString()),
                                    child.child("Date_cours").getValue().toString()

                            ));

                        }

                        Log.d("Name_course",child.child("Name_Cours").getValue().toString());
                    }
                    listView_result.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    if (adapter.getCount()==0) {
                        AlertDialog.Builder alert = new AlertDialog.Builder(Result_Research_Activity.this);
                        alert.setMessage("Aucun cours trouvé ! ")
                                .setIcon(android.R.drawable.stat_notify_error)
                                .setTitle("Alert")
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        startActivity(new Intent(Result_Research_Activity.this,Simple_Search_Activity.class));

                                    }
                                }).show();
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });


            Log.d("Name_course",Name_course);

        }
else if(type==2){

            ens_key=  b.getString("key_Enseignant");
            fil_key= b.getString("key_Filiere");
            Mat_key= b.getString("key_Matiere");
            niv_key= b.getString("key_Niveau");
            Log.d("Name_course",""+type+".."+ens_key);
            Log.d("fffffffff",ens_key);

            spinner_result.add(ens_key);
            spinner_result.add(fil_key);
            spinner_result.add(Mat_key);
            spinner_result.add(niv_key);

            myRef_cours.addValueEventListener(new ValueEventListener() {
                @Override

                public void onDataChange(DataSnapshot dataSnapshot) {

                    for (DataSnapshot child : dataSnapshot.getChildren()){
                        String ensChild=child.child("Enseignant").child("Full_Name").getValue().toString();
                        String FilChild=child.child("Filiere").child("Nom_Filiere").getValue().toString();
                        String MatChild=child.child("Matiere").child("libelle").getValue().toString();
                        String NivChild=child.child("Niveau").child("Niv").getValue().toString();
                        /******************************Case 1***************************************/

                        if (ensChild.contains(ens_key)||FilChild.contains(Mat_key)||MatChild.contains(fil_key)||NivChild.contains(niv_key)){
                                res_list.add(new Cours(child.child("id_cours").getValue().toString(),
                                        child.child("Name_Cours").getValue().toString(),
                                        new Enseignant(child.child("Enseignant").child("Full_Name").getValue().toString()),
                                        new Matiere(child.child("Matiere").child("id_Matiere").getValue().toString()
                                                ,child.child("Matiere").child("libelle").getValue().toString()),
                                        new Niveau(child.child("Niveau").child("Niv").getValue().toString()),
                                        new Filiere(child.child("Filiere").child("Nom_Filiere").getValue().toString()),
                                        child.child("Date_cours").getValue().toString()
                                ));


                        }


                        Log.d("Name_course",child.child("Name_Cours").getValue().toString());
                    }
                    listView_result.setAdapter(adapter);

                    adapter.notifyDataSetChanged();
                    if (adapter.getCount()==0) {
                        AlertDialog.Builder alert = new AlertDialog.Builder(Result_Research_Activity.this);
                        alert.setMessage("Aucun cours trouvé ! ")
                                .setIcon(android.R.drawable.stat_notify_error)
                                .setTitle("Alert")
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        startActivity(new Intent(Result_Research_Activity.this,Advanced_search_Activity.class));

                                    }
                                }).show();
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });


        }

    }
    public class MyCoursAdabter extends BaseAdapter {
        ArrayList<Cours> items_ListView = new ArrayList<>();

        MyCoursAdabter(ArrayList<Cours> items_ListView) {
            this.items_ListView = items_ListView;
        }

        @Override
        public int getCount() {
            return items_ListView.size();
        }

        @Override
        public Object getItem(int i) {
            return items_ListView.get(i).getCoursId();
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater li = getLayoutInflater();
            View view1 = li.inflate(R.layout.row_rsult_research, null);
            TextView Course_Name = (TextView) view1.findViewById(R.id.Course_Name);
            TextView Filiere_txt = (TextView) view1.findViewById(R.id.Filiere_txt);
            TextView enseignant_txt = (TextView) view1.findViewById(R.id.enseignant_txt);
            TextView Matiere_txt = (TextView) view1.findViewById(R.id.Matiere_txt);
            TextView Niveau_txt = (TextView) view1.findViewById(R.id.Niveau_txt);
            TextView Date_txt = (TextView) view1.findViewById(R.id.Date_txt);
            Button Download_file_btn = (Button) view1.findViewById(R.id.Download_file_btn);
          //  Button View_file_btn = (Button) view1.findViewById(R.id.View_file_btn);
            final TextView id_hide = (TextView) view1.findViewById(R.id.id_hide);
            id_hide.setText(items_ListView.get(i).getCoursId());
            Course_Name.setText("Nom du cours: "+items_ListView.get(i).getCoursName());
            Filiere_txt.setText("Filiere: "+items_ListView.get(i).getCours_Filiere().getFiliere_Nom());
            enseignant_txt.setText("Nom Enseignant: "+items_ListView.get(i).getCours_Enseignant().getFullName());
            Matiere_txt.setText("Nom du Matiere: "+items_ListView.get(i).getCours_Matiere().getLibelle_Matiere());
            Niveau_txt.setText("Niveau: "+items_ListView.get(i).getCours_Niveau().getNiveau_Number());
            Date_txt.setText("Date: "+items_ListView.get(i).getDate());

            Download_file_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.v("link",""+id_hide.getText().toString());
                    FirebaseStorage storage = FirebaseStorage.getInstance();
                    StorageReference storageRef = storage.getReferenceFromUrl(
                            "gs://potvot-bb903.appspot.com").
                            child("Course/").child(id_hide.getText().toString()).child("a.pdf");
                    String Uri="gs://potvot-bb903.appspot.com/Course/"+id_hide.getText().toString()+"/a.pdf";
                    Log.v("link",""+Uri);
                    storageRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setData(uri);
                            startActivity(i);



                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Handle any errors
                        }
                    });
                    //potvot-bb903.appspot.com/Course/1234548916zepnfnmiklzOIFZAMzda26/a.pdf
                }
            });


    return view1;
    }

}
}
