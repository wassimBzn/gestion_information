package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.gest_infos.gestioninformation.Activitys.Generic_Activitys.Accueil_NoLogin_Activity;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Matiere;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Module;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Note;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.absance;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class visualise_note extends AppCompatActivity {
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualise_note);
        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals("Home")){
                    startActivity(new Intent(getBaseContext(),acceuil_student.class));
                }else if (menuItem.getTitle().equals("Autre service")){
                    startActivity(new Intent(getBaseContext(),Accueil_NoLogin_Activity.class));
                }else if (menuItem.getTitle().equals("Absence")){
                    startActivity(new Intent(getBaseContext(),seeAllAbsStudents.class));
                }else if (menuItem.getTitle().equals("Demander service")){
                    startActivity(new Intent(getBaseContext(),Request_Service.class));
                }else if (menuItem.getTitle().equals("Notes")){
                    startActivity(new Intent(getBaseContext(),visualise_note.class));
                }else if (menuItem.getTitle().equals("deconnecter")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });
        progressDialog = new ProgressDialog(this);
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        /**************get module*********************************************************/
        //get Matieres
        DatabaseReference myRef_module= database.getReference("Etudiant").child("Groupe").child("TI1").child("Module");
        // final ListView list=(ListView)findViewById(R.id.liste_note);
        final ArrayList<Module> res_list_module=new ArrayList<>();

        // final MyNoteAdabter adapter=new MyNoteAdabter(res_list_matiere);
        myRef_module.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()){
                    res_list_module.add(new Module(child.child("nom_module").getKey().toString(),
                            child.child("nom_module").getValue().toString()));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
/*****************************************************get Matiere*********/
//get Matieres
        DatabaseReference myRef_Matiere= database.getReference("Etudiant").child("Groupe").child("TI1").child("Matieres_noms");
       // final ListView list=(ListView)findViewById(R.id.liste_note);
        final ArrayList<Matiere> res_list_matiere=new ArrayList<>();

       // final MyNoteAdabter adapter=new MyNoteAdabter(res_list_matiere);
        myRef_Matiere.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()){
                    res_list_matiere.add(new Matiere(child.child("nom_Matiere").getKey().toString(),
                            child.child("nom_Matiere").getValue().toString()));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
/**********************************************************************************/

       //TODo:: receiving NOTES
        DatabaseReference myRef_note= database.getReference("Etudiant").child("Groupe").child("TI1").child("students").child("03665584").child("Notes");
        final ListView list=(ListView)findViewById(R.id.liste_note);
        final ArrayList<Note> res_list=new ArrayList<>();

        final MyNoteAdabter adapter=new MyNoteAdabter(res_list);
        myRef_note.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (int i=0;i<res_list_module.size();i++){

                        for (DataSnapshot child : dataSnapshot.getChildren()){
                            /*if (child.child(res_list_module.get(i).getNom_module().toString()).exists()){
                                if (child.child(res_list_module.get(i).getNom_module().toString())
                                .child("Matiers").child(res_list_matiere.get(j).getLibelle_Matiere().toString()).exists()){
*/
                            Log.v("1-1-",res_list_module.get(i).getNom_module().toString());
                            Log.v("1-1-",res_list_matiere.get(i).getLibelle_Matiere().toString());
                            res_list.add(new Note(
                                   /********/
                                   new Module(res_list_module.get(i).getId_module().toString(),
                                   res_list_module.get(i).getNom_module().toString()),
                                  /*************/
                                           new Matiere(res_list_matiere.get(i).getMatier_Id().toString(),
                                           res_list_matiere.get(i).getLibelle_Matiere().toString()),
                                   /***************/

                                           child.child(res_list_module.get(i).getNom_module().toString()).
                                                   child("Matiers ").child(res_list_matiere.get(i).getLibelle_Matiere().toString()).
                                                   child("DS").getValue().toString(),
                                   /*******************/
                                           child.child(res_list_module.get(i).getNom_module().toString()).
                                                   child("Matiers ").child(res_list_matiere.get(i).getLibelle_Matiere().toString()).
                                                   child("TP").getValue().toString(),
                                    /********************/
                                           child.child(res_list_module.get(i).getNom_module().toString()).
                                                   child("Matiers ").child(res_list_matiere.get(i).getLibelle_Matiere().toString()).
                                                   child("NP").getValue().toString(),
                                           /********************/
                                           child.child(res_list_module.get(i).getNom_module().toString()).
                                                   child("Matiers ").child(res_list_matiere.get(i).getLibelle_Matiere().toString()).
                                                   child("exam").getValue().toString(),
                                           /********************/
                                           Double.parseDouble( child.child(res_list_module.get(i).getNom_module().toString()).
                                                   child("Matiers ").child(res_list_matiere.get(i).getLibelle_Matiere().toString()).
                                                   child("Moy").getValue().toString())

                                   )

                                   );


                    }
                }

                list.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }




    public class MyNoteAdabter extends BaseAdapter {
        ArrayList<Note> items_ListView = new ArrayList<>();

        MyNoteAdabter(ArrayList<Note> items_ListView) {
            this.items_ListView = items_ListView;
        }

        @Override
        public int getCount() {
            return items_ListView.size();
        }

        @Override
        public Object getItem(int i) {
            return items_ListView.get(i).getDS();
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater li = getLayoutInflater();
            View view1 = li.inflate(R.layout.row_note, null);
            final LinearLayout ln_note=(LinearLayout)view1.findViewById(R.id.ln_note);
            final TextView DS = (TextView) view1.findViewById(R.id.DS);
            final TextView NP = (TextView) view1.findViewById(R.id.NP);
            final TextView TP = (TextView) view1.findViewById(R.id.TP);
            final TextView exam = (TextView) view1.findViewById(R.id.exam);
            final TextView Moy = (TextView) view1.findViewById(R.id.Moy);
            final TextView module = (TextView) view1.findViewById(R.id.module);
            final TextView Matiere = (TextView) view1.findViewById(R.id.nom_Matiere);
            module.setText("Module : "+items_ListView.get(i).getModule());
            Matiere.setText("Matiere : "+items_ListView.get(i).getMatiere());
            DS.setText("note de DS : "+items_ListView.get(i).getDS());
            exam.setText("note de Examen : "+items_ListView.get(i).getExam());
            NP.setText("note non présentielle : "+items_ListView.get(i).getNP());
            TP.setText("note de TP : "+items_ListView.get(i).getTP());
            Moy.setText("Moyenne de ce matiere : "+items_ListView.get(i).getMoy());
                Double moy= items_ListView.get(i).getMoy();
                if (moy<10)
                    ln_note.setBackground(getDrawable(R.drawable.red));
                else
                    ln_note.setBackground(getDrawable(R.drawable.images));

            return view1;
        }

    }


}
