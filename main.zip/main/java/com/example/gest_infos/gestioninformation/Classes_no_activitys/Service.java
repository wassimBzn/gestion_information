package com.example.gest_infos.gestioninformation.Classes_no_activitys;

import java.lang.ref.SoftReference;

/**
 * Created by root on 1/11/18.
 */

public class Service {
 private    String id_service;
    private String Name_service ;
    private  String Email_service;
    private String Request_Service;
    public Service (String id_service,String Name_service,String Email_service,
    String Request_Service ){
        this.Email_service=Email_service;
        this.id_service=id_service;
        this.Name_service=Name_service;
        this.Request_Service=Request_Service;

    }

    public String getId_service() {
        return id_service;
    }

    public String getName_service() {
        return Name_service;
    }

    public String getEmail_service() {
        return Email_service;
    }

    public String getRequest_Service() {
        return Request_Service;
    }
}
