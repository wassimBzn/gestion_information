package com.example.gest_infos.gestioninformation.Classes_no_activitys;

/**
 * Created by root on 11/22/17.
 */

public class Matiere {
    private String Matier_Id;
    private String Libelle_Matiere;
    private Niveau NiveauMatier;
    private Filiere Filier_Matiere;

    public Matiere(String Matier_Id, String Libelle_Matiere
                   ){
        this.Matier_Id=Matier_Id;
           this.Libelle_Matiere=Libelle_Matiere;

    }



    public String getMatier_Id() {
        return Matier_Id;
    }

    public String getLibelle_Matiere() {
        return Libelle_Matiere;
    }

    public Niveau getNiveauMatier() {
        return NiveauMatier;
    }

    public Filiere getFilier_Matiere() {
        return Filier_Matiere;
    }
}
