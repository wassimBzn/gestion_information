package com.example.gest_infos.gestioninformation.Classes_no_activitys;

/**
 * Created by root on 12/11/17.
 */

public class student {
    private String Cin;
    private String Date_nes;
    private String Nom_etudiant;
    private String Nom_Filiere;
    private String Niv;

    public student(String cin, String date_nes, String nom_etudiant, String nom_filiere, String niv) {
        this.Cin = cin;
        this.Date_nes = date_nes;
        this.Nom_etudiant = nom_etudiant;
        this.Nom_Filiere = nom_filiere;
        this.Niv = niv;
    }

    public String getCin() {
        return Cin;
    }

    public String getDate_nes() {
        return Date_nes;
    }

    public String getNom_etudiant() {
        return Nom_etudiant;
    }

    public String getNom_Filiere() {
        return Nom_Filiere;
    }

    public String getNiv() {
        return Niv;
    }
}
