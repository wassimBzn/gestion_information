package com.example.gest_infos.gestioninformation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys.AdminLogin_Activity;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys.Admin_choice_list;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys.Insert_CourseActivity;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.login_student;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant.login_prof;

public class login_choice extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_choice);
    }

    public void professor_login(View view) {
        startActivity(new Intent(login_choice.this,login_prof.class));

    }

    public void Login_Admin(View view) {
        startActivity(new Intent(login_choice.this,AdminLogin_Activity.class));

    }

    public void Student_login(View view) {
        startActivity(new Intent(login_choice.this,login_student.class));

    }
}
