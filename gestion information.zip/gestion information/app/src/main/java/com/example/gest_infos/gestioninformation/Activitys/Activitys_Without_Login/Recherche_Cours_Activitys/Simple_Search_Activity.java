package com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.example.gest_infos.gestioninformation.R;

public class Simple_Search_Activity extends AppCompatActivity {
EditText Course_Name_txt_reserch_simple;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple__search_);
        Course_Name_txt_reserch_simple=(EditText)findViewById(R.id.Course_Name_txt_reserch_simple);
    }

    public void rechrch_simple_reserch_btn(View view) {
        Course_Name_txt_reserch_simple.getText().toString();
        Intent intent =new Intent(Simple_Search_Activity.this,Result_Research_Activity.class);
        intent.putExtra("Name_Cours",Course_Name_txt_reserch_simple.getText().toString());
        intent.putExtra("Type",1);
        Log.d("eeeeeeeeeee","ALl Done!");
        startActivity(intent);
    }
}

