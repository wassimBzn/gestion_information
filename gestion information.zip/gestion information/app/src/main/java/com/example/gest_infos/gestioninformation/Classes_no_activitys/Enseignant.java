package com.example.gest_infos.gestioninformation.Classes_no_activitys;

/**
 * Created by root on 11/22/17.
 */

public class Enseignant {
    private String Cin;
    private String FullName;

    public Enseignant( String FullName){

        this.FullName=FullName;
    }

    public String getCin() {
        return Cin;
    }

    public String getFullName() {
        return FullName;
    }
}
