package com.example.gest_infos.gestioninformation.Classes_no_activitys;

/**
 * Created by root on 11/22/17.
 */

public class Niveau {
    private String Niveau_ID;
    private String Niveau_Number;
    private String Nivea_year;
    public Niveau( String Niveau_Number ){

        this.Niveau_Number=Niveau_Number;


    }

    public String getNiveau_ID() {
        return Niveau_ID;
    }

    public String getNiveau_Number() {
        return Niveau_Number;
    }

    public String getNivea_year() {
        return Nivea_year;
    }
}
