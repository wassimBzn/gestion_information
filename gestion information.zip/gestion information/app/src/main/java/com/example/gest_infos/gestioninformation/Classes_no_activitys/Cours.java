package com.example.gest_infos.gestioninformation.Classes_no_activitys;

/**
 * Created by root on 11/22/17.
 */

public class Cours {
    private String CoursId;
    private String CoursName;
    private Enseignant Cours_Enseignant;
    private Matiere Cours_Matiere;
    private Niveau Cours_Niveau;
    private Filiere Cours_Filiere;
    private String Date;

    public Cours(String CoursId,
                 String CoursName,
                 Enseignant Cours_Enseignant,
                 Matiere Cours_Matiere,
                 Niveau Cours_Niveau,
                 Filiere Cours_Filiere,
                 String Date){
        this.CoursId=CoursId;
        this.CoursName=CoursName;
        this.Cours_Enseignant=Cours_Enseignant;
        this.Cours_Matiere=Cours_Matiere;
        this.Cours_Niveau=Cours_Niveau;
        this.Cours_Filiere=Cours_Filiere;
        this.Date=Date;
    }

    public String getCoursId() {
        return CoursId;
    }

    public String getCoursName() {
        return CoursName;
    }

    public Enseignant getCours_Enseignant() {
        return Cours_Enseignant;
    }

    public Niveau getCours_Niveau() {
        return Cours_Niveau;
    }

    public Matiere getCours_Matiere() {
        return Cours_Matiere;
    }

    public Filiere getCours_Filiere() {
        return Cours_Filiere;
    }

    public String getDate() {
        return Date;
    }
}
