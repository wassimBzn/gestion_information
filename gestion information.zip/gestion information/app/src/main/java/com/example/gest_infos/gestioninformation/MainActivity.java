package com.example.gest_infos.gestioninformation;

import android.content.Intent;
import android.sax.StartElementListener;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys.AdminLogin_Activity;
import com.example.gest_infos.gestioninformation.Activitys.Generic_Activitys.Accueil_NoLogin_Activity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Continue_btn(View view) {
        startActivity(new Intent(MainActivity.this, Accueil_NoLogin_Activity.class));
    }

    public void Login_btn_Generic(View view) {
        startActivity(new Intent(MainActivity.this, AdminLogin_Activity.class));

    }
}
