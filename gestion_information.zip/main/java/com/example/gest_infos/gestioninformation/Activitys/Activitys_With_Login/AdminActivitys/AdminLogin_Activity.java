package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys;

import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class AdminLogin_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login_);
        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals(" Home ")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });
    }


    public void Signin_Admin_btn(View view) {
        startActivity(new Intent(AdminLogin_Activity.this,Admin_choice_list.class));
    }
}
