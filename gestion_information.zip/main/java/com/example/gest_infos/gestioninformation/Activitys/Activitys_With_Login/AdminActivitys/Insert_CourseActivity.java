package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.gest_infos.gestioninformation.Classes_no_activitys.Cours;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Enseignant;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class Insert_CourseActivity extends AppCompatActivity {
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert__course);

        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals("Home ")){
                    startActivity(new Intent(getBaseContext(),Admin_choice_list.class));
                }else if (menuItem.getTitle().equals("Cours ")){
                    startActivity(new Intent(getBaseContext(),Insert_CourseActivity.class));
                }else if (menuItem.getTitle().equals("Service ")){
                    startActivity(new Intent(getBaseContext(),View_Requests.class));
                }
                else if (menuItem.getTitle().equals("deconnecter ")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });


    final   Spinner Recherche_Advanced_enseignant_spinner=(Spinner)findViewById(R.id.enseignant_spinner_insert);
        final   Spinner Recherche_Advanced_Matiere_spinner=(Spinner)findViewById(R.id.Matiere_spinner_insert);
        final   Spinner Recherche_Advanced_Fieliere_spinner=(Spinner)findViewById(R.id.Filiere_spinner_insert);
        final   Spinner Recherche_Advanced_niveau_spinner=(Spinner)findViewById(R.id.Niveau_spinner_insert);

        final  Spinner Recherche_Advanced_enseignant_spinner_key=(Spinner)findViewById(R.id.enseignant_spinner_insert_key);
        final  Spinner Recherche_Advanced_Matiere_spinner_key=(Spinner)findViewById(R.id.Matiere_spinner_insert_key);
        final  Spinner Recherche_Advanced_Fieliere_spinner_key=(Spinner)findViewById(R.id.Filiere_spinner_insert_key);
        final  Spinner Recherche_Advanced_niveau_spinner_key=(Spinner)findViewById(R.id.Niveau_spinner_insert_key);


        progressDialog = new ProgressDialog(this);
        final ArrayList<String> values_Enseignant=new ArrayList<>();
        values_Enseignant.add("Enter Enseignant Name");

        final ArrayList<String> keys_Enseignant=new ArrayList<>();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_enseignant = database.getReference("Enseignant");
        final  ArrayAdapter<String> adapter1=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values_Enseignant);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final  ArrayAdapter<String> adapter2=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,keys_Enseignant);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();


        myRef_enseignant.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    progressDialog.dismiss();
                    values_Enseignant.add(child.child("Full_Name").getValue().toString());
                    keys_Enseignant.add(child.child("id_enseignant").getValue().toString());

                    Log.d("7aaa",""+child.child("operation_category").getValue());
                    Recherche_Advanced_enseignant_spinner.setAdapter(adapter1);
                    Recherche_Advanced_enseignant_spinner_key.setAdapter(adapter2);

                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
/*******************************************************************************/
        final ArrayList<String> values_Matiere=new ArrayList<>();

        values_Matiere.add("Enter le Nom de la matiere");

        final ArrayList<String> keys_Matiere=new ArrayList<>();
        DatabaseReference myRef_matiere = database.getReference("Matiere");
        final  ArrayAdapter<String> adapter3=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values_Matiere);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final  ArrayAdapter<String> adapter4=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,keys_Matiere);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        myRef_matiere.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    values_Matiere.add(child.child("libelle").getValue().toString());
                    keys_Matiere.add(child.child("id_Matiere").getValue().toString());

                    Log.d("7aaa",""+child.child("operation_category").getValue());
                    progressDialog.dismiss();
                    Recherche_Advanced_Matiere_spinner.setAdapter(adapter3);
                    Recherche_Advanced_Matiere_spinner_key.setAdapter(adapter4);
                 //   Mat_key=Recherche_Advanced_Matiere_spinner.getSelectedItem().toString();
                }



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
/*************************************************************************************************************************/
        final ArrayList<String> values_Filiere=new ArrayList<>();

        values_Filiere.add("Enter la Filiere");

        final ArrayList<String> keys_Filiere=new ArrayList<>();
        DatabaseReference myRef_Filiere = database.getReference("Filiere");
        final  ArrayAdapter<String> adapter5=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values_Filiere);
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final  ArrayAdapter<String> adapter6=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,keys_Filiere);
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        myRef_Filiere.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    values_Filiere.add(child.child("Nom_Filiere").getValue().toString());
//                    keys_Filiere.add(child.child("id_Filiere").getValue().toString());
                    Recherche_Advanced_Fieliere_spinner.setAdapter(adapter5);
                    Recherche_Advanced_Fieliere_spinner_key.setAdapter(adapter6);
                    //fil_key=Recherche_Advanced_Fieliere_spinner.getSelectedItem().toString();
                }




            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        /*************************************************************************************************************************/
        final ArrayList<String> values_Niveau=new ArrayList<>();

        values_Niveau.add("Enter le Niveau");

        final ArrayList<String> keys_Niveau=new ArrayList<>();
        DatabaseReference myRef_Niveau = database.getReference("Niveau");
        final  ArrayAdapter<String> adapter7=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values_Niveau);
        adapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final  ArrayAdapter<String> adapter8=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,keys_Niveau);
        adapter8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        myRef_Niveau.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    values_Niveau.add(child.child("Niv").getValue().toString());
                    keys_Niveau.add(child.child("id_Niveau").getValue().toString());


                    Recherche_Advanced_niveau_spinner.setAdapter(adapter7);
                  //  niv_key=Recherche_Advanced_niveau_spinner.getSelectedItem().toString();
                  //  Log.d("niv_key",niv_key);
                    Recherche_Advanced_niveau_spinner_key.setAdapter(adapter8);
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }
    public void uplod_btn(View view) {

    }

    public void uplod_btn_to_FB(View view) {
        // Create a storage reference from our app
        StorageReference storageRef = FirebaseStorage.getInstance().getReference();
        // Create a reference to "mountains.jpg"
        StorageReference mountainsRef = storageRef.child("Course/") ;
        // Create a reference to 'images/mountains.jpg'
        StorageReference mountainImagesRef = storageRef.child("images/mountains.jpg");
        // While the file names are the same, the references point to different files
        mountainsRef.getName().equals(mountainImagesRef.getName());    // true
        mountainsRef.getPath().equals(mountainImagesRef.getPath());    // false
    }
}
