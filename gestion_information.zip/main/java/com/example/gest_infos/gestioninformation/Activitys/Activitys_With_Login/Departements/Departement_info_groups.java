package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements;

import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant.Accueil_prof;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant.see_All_students;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class Departement_info_groups extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_departement_info_groups);
        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals(" Home")){
                    startActivity(new Intent(getBaseContext(),Accueil_prof.class));
                }else if (menuItem.getTitle().equals(" deconncter")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });
    }




    public void TI1(View view) {
        Intent intent=new Intent(Departement_info_groups.this,see_All_students.class);
        intent.putExtra("group","TI1");
        startActivity(intent);

    }

    public void TI2(View view) {
    }

    public void TI3(View view) {
    }

    public void TI4(View view) {
    }

    public void TI5(View view) {
    }

    public void TI6(View view) {
    }

    public void DSI3(View view) {
    }

    public void RSI3(View view) {
    }

    public void MDW3(View view) {
    }

    public void DSI5(View view) {
    }

    public void RSI5(View view) {
    }
    public void MDW5(View view) {
    }
}
