package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.gest_infos.gestioninformation.Activitys.Generic_Activitys.Accueil_NoLogin_Activity;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.absance;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class seeAllAbsStudents extends AppCompatActivity {
    private ProgressDialog progressDialog;
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_all_abs_students);

            FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
            febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
                @Override
                public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                    return true ;
                }

                @Override
                public boolean onMenuItemSelected(MenuItem menuItem) {
                    if (menuItem.getTitle().equals("Home")){
                        startActivity(new Intent(getBaseContext(),acceuil_student.class));
                    }else if (menuItem.getTitle().equals("Autre service")){
                        startActivity(new Intent(getBaseContext(),Accueil_NoLogin_Activity.class));
                    }else if (menuItem.getTitle().equals("Absence")){
                        startActivity(new Intent(getBaseContext(),seeAllAbsStudents.class));
                    }else if (menuItem.getTitle().equals("Demander service")){
                        startActivity(new Intent(getBaseContext(),Request_Service.class));
                    }else if (menuItem.getTitle().equals("Notes")){
                        startActivity(new Intent(getBaseContext(),visualise_note.class));
                    }else if (menuItem.getTitle().equals("deconnecter")){
                        startActivity(new Intent(getBaseContext(),login_choice.class));
                    }
                    return true;
                }

                @Override
                public void onMenuClosed() {

                }
            });
            progressDialog = new ProgressDialog(this);
            final FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef_absance_programmation = database.getReference("Etudiant").child("Groupe").child("TI1").child("03665584").child("Absance").child("programmation");
            final ListView list=(ListView)findViewById(R.id.see_all_abs_students_listeView);
            final ArrayList<absance> res_list=new ArrayList<>();

            final MyAbsStudAdabter adapter=new MyAbsStudAdabter(res_list);
            myRef_absance_programmation.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    int id1=0;
                    for (DataSnapshot child : dataSnapshot.getChildren()){
                        id1++;

                            res_list.add(new absance(  child.child("id_Absance").getValue().toString(),
                                    child.child("Matiere").getValue().toString(),
                                    child.child("date_absance").getValue().toString(),
                                    child.child("id_Matiere").getValue().toString(),
                                     id1 ));
                    }
                    list.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            DatabaseReference myRef_absance_english = database.getReference("Etudiant").child("Groupe").child("TI1").child("students").child("03665584").child("Absance").child("english");
            myRef_absance_english.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    int id1=0;
                    for (DataSnapshot child : dataSnapshot.getChildren()){
                        id1++;

                        res_list.add(new absance(  child.child("id_Absance").getValue().toString(),
                                child.child("Matiere").getValue().toString(),
                                child.child("date_absance").getValue().toString(),
                                child.child("id_Matiere").getValue().toString(),
                                id1 ));
                    }
                    list.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

        }




    public class MyAbsStudAdabter extends BaseAdapter {
        ArrayList<absance> items_ListView = new ArrayList<>();

        MyAbsStudAdabter(ArrayList<absance> items_ListView) {
            this.items_ListView = items_ListView;
        }

        @Override
        public int getCount() {
            return items_ListView.size();
        }

        @Override
        public Object getItem(int i) {
            return items_ListView.get(i).getId_Absance();
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater li = getLayoutInflater();
            View view1 = li.inflate(R.layout.row_see_all_absance, null);
            final GridLayout gd=(GridLayout)view1.findViewById(R.id.gID);
            final TextView Nom_Matiere = (TextView) view1.findViewById(R.id.matiere_name_st_abs);
            final TextView result_st_abs = (TextView) view1.findViewById(R.id.result_st_abs);
             final TextView date_abs = (TextView) view1.findViewById(R.id.date_absance);
            final TextView Matiere_abs = (TextView) view1.findViewById(R.id.Matiere_abs);
            final TextView nbabsance = (TextView) view1.findViewById(R.id.nbabsance);

            nbabsance.setText(""+items_ListView.get(i).getNum_absance());
            Nom_Matiere.setText("Matiere: "+items_ListView.get(i).getMatiere());
            //result_st_abs.setText(items_ListView.get(i).Num_absance;
            date_abs.setText(items_ListView.get(i).getDate_absance());
            Matiere_abs.setText(items_ListView.get(i).getMatiere());
            if (Integer.parseInt(nbabsance.getText().toString())>3){
                result_st_abs.setText("Etat: Eliminer");
                gd.setBackground(getDrawable(R.drawable.red));

            }else if(Integer.parseInt(nbabsance.getText().toString())>2){
                result_st_abs.setText("Etat: Attention!");
                gd.setBackground(getDrawable(R.drawable.orange));


            }else if(Integer.parseInt(nbabsance.getText().toString())>1){
                result_st_abs.setText("Etat: Normale");
                gd.setBackground(getDrawable(R.drawable.yellow));

            }else if(Integer.parseInt(nbabsance.getText().toString())==1){
                result_st_abs.setText("Etat: super");
             gd.setBackground(getDrawable(R.drawable.images));

            }else if(Integer.parseInt(nbabsance.getText().toString())==0){
                result_st_abs.setText("Etat: super you have No absense !  ");
                gd.setBackground(getDrawable(R.drawable.images));


            }
            // result_st_abs.setText("Etat: "+items_ListView.get(i).getId_Matiere());
            Button detail_st_abs=(Button)view1.findViewById(R.id.detail_st_abs);
            detail_st_abs.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent=new Intent(seeAllAbsStudents.this,detail_abs_students.class);
        intent.putExtra("nbabsance",Integer.parseInt(nbabsance.getText().toString()));
        intent.putExtra("Etat",result_st_abs.getText().toString()) ;
        intent.putExtra("date_abs", date_abs.getText().toString() );
        intent.putExtra("Matiere_abs", Matiere_abs.getText().toString() );

        startActivity(intent);

    }
});
            return view1;
        }

    }
}
