package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys.Result_Research_Activity;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.Cours;
import com.example.gest_infos.gestioninformation.Classes_no_activitys.student;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class see_All_students extends AppCompatActivity {

    private ProgressDialog progressDialog;
    String group;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see__all_students);
        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals(" Home")){
                    startActivity(new Intent(getBaseContext(),Accueil_prof.class));
                }else if (menuItem.getTitle().equals(" deconncter")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });

        progressDialog = new ProgressDialog(this);
        Bundle b= getIntent().getExtras();
          group=b.getString("group") ;
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_student = database.getReference("Etudiant").child("Groupe").child(group).child("students");
        final ListView list=(ListView)findViewById(R.id.see_all_student_list_view);
        final ArrayList<student> res_list=new ArrayList<>();
        final MyStudentAdabter adapter=new MyStudentAdabter(res_list);
        myRef_student.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                progressDialog.dismiss();
                for (DataSnapshot child : dataSnapshot.getChildren()){
                    res_list.add(new student(
                            child.child("Cin").getValue().toString(),
                            child.child("Date_nes").getValue().toString(),
                            child.child("Nom_etudiant").getValue().toString(),
                            child.child("Filiere").child("Nom_Filiere").getValue().toString(),
                            child.child("Niveau").child("Niv").getValue().toString()));
                }
                list.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }






public class MyStudentAdabter extends BaseAdapter {
    ArrayList<student> items_ListView = new ArrayList<>();

    MyStudentAdabter(ArrayList<student> items_ListView) {
        this.items_ListView = items_ListView;
    }

    @Override
    public int getCount() {
        return items_ListView.size();
    }

    @Override
    public Object getItem(int i) {
        return items_ListView.get(i).getCin();
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater li = getLayoutInflater();
        View view1 = li.inflate(R.layout.row_all_students, null);
        TextView Nom_etudiant = (TextView) view1.findViewById(R.id.Nom_etudiant);
        TextView Date_nes = (TextView) view1.findViewById(R.id.Date_nes);
        final TextView Cin = (TextView) view1.findViewById(R.id.Cin);
        final TextView grouppo = (TextView) view1.findViewById(R.id.grouppo);
        final TextView Cin1 = (TextView) view1.findViewById(R.id.Cin1);
        Bundle b=getIntent().getExtras();
        //group=b.getString("group") ;
        Log.v("nom",group);
        Log.v("grou9","0"+grouppo.getText().toString());

        TextView Nom_Filiere = (TextView) view1.findViewById(R.id.Nom_Filiere);
        TextView Niv = (TextView) view1.findViewById(R.id.Niv);
        Button add_Absance =(Button)view1.findViewById(R.id.add_Absance);
        Nom_etudiant.setText("Nom du l'étudiant: "+items_ListView.get(i).getNom_etudiant());
        Date_nes.setText("Date de Naissance: "+items_ListView.get(i).getDate_nes());
        Cin.setText("Cin: "+items_ListView.get(i).getCin());
        grouppo.setText(group);
         Log.v("grou9","1"+grouppo.getText().toString());

        Cin1.setText(items_ListView.get(i).getCin());
        Nom_Filiere.setText("Nom du Filiere: "+items_ListView.get(i).getNom_Filiere());
        Niv.setText("Niveau: "+items_ListView.get(i).getNiv());
        add_Absance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(see_All_students.this,chose_matiere.class);
                intent.putExtra("Cin",Cin1.getText().toString());
                intent.putExtra("groupe",grouppo.getText().toString());
                Log.v("grou9","2"+grouppo.getText().toString());
                startActivity(intent);

            }
        });

        return view1;
    }

}
}
