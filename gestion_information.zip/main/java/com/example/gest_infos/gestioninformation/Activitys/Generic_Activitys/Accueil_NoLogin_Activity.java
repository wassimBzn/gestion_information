package com.example.gest_infos.gestioninformation.Activitys.Generic_Activitys;

import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.Request_Service;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.acceuil_student;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.seeAllAbsStudents;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys.Emploi;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys.Recherche_Cour_Choices;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class Accueil_NoLogin_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil__no_login_);
        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals("Home")){
                    startActivity(new Intent(getBaseContext(),acceuil_student.class));
                }else if (menuItem.getTitle().equals("Autre service")){
                    startActivity(new Intent(getBaseContext(),Accueil_NoLogin_Activity.class));
                }else if (menuItem.getTitle().equals("Absence")){
                    startActivity(new Intent(getBaseContext(),seeAllAbsStudents.class));
                }else if (menuItem.getTitle().equals("Demander service")){
                    startActivity(new Intent(getBaseContext(),Request_Service.class));
                }else if (menuItem.getTitle().equals("deconnecter")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }else if (menuItem.getTitle().equals("Notes")){
                    startActivity(new Intent(getBaseContext(),seeAllAbsStudents.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });
    }

    public void Emploi_Choice_btn(View view) {
        startActivity(new Intent(Accueil_NoLogin_Activity.this, Emploi.class));

    }

    public void Notes_btn_Choice(View view) {
    }

    public void Cours_btn_choice(View view) {
        startActivity(new Intent(Accueil_NoLogin_Activity.this, Recherche_Cour_Choices.class));
    }
}


