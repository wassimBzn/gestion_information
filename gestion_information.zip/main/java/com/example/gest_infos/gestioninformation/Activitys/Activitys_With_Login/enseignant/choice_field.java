package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.enseignant;

import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements.Departement_Gestion_groups;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements.Departement_Mecanique;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.Departements.Departement_info_groups;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class choice_field extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_field);
        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals(" Home")){
                    startActivity(new Intent(getBaseContext(),Accueil_prof.class));
                }else if (menuItem.getTitle().equals(" deconncter")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });

    }

    public void Dep_Mecanique(View view) {
        startActivity(new Intent(choice_field.this, Departement_Mecanique.class));

    }

    public void Dep_Gestion(View view) {
        startActivity(new Intent(choice_field.this, Departement_Gestion_groups.class));

    }

    public void Dep_informatique(View view) {
        startActivity(new Intent(choice_field.this, Departement_info_groups.class));

    }
}
