package com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.AdminActivitys;

import android.content.Intent;
import android.support.design.internal.NavigationMenu;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.Request_Service;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.acceuil_student;
import com.example.gest_infos.gestioninformation.Activitys.Activitys_With_Login.StudentActivitys.seeAllAbsStudents;
import com.example.gest_infos.gestioninformation.Activitys.Generic_Activitys.Accueil_NoLogin_Activity;
import com.example.gest_infos.gestioninformation.R;
import com.example.gest_infos.gestioninformation.login_choice;

import io.github.yavski.fabspeeddial.FabSpeedDial;

public class Admin_choice_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_choice_list);
        FabSpeedDial febSpeedDial=(FabSpeedDial)findViewById(R.id.FebSpeedDial);
        febSpeedDial.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true ;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                if (menuItem.getTitle().equals("Home ")){
                    startActivity(new Intent(getBaseContext(),Admin_choice_list.class));
                }else if (menuItem.getTitle().equals("Cours ")){
                    startActivity(new Intent(getBaseContext(),Insert_CourseActivity.class));
                }else if (menuItem.getTitle().equals("Service ")){
                    startActivity(new Intent(getBaseContext(),View_Requests.class));
                }
                else if (menuItem.getTitle().equals("deconnecter ")){
                    startActivity(new Intent(getBaseContext(),login_choice.class));
                }
                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });
    }


    public void Insert_Course_btn(View view) {
        startActivity(new Intent(Admin_choice_list.this,Insert_CourseActivity.class));

    }

    public void View_Service_Requests(View view) {
        startActivity(new Intent(Admin_choice_list.this,View_Requests.class));

    }
}
