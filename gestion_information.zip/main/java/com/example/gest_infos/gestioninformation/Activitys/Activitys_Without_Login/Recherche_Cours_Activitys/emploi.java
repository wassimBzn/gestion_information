package com.example.gest_infos.gestioninformation.Activitys.Activitys_Without_Login.Recherche_Cours_Activitys;

/**
 * Created by root on 12/5/17.
 */

public class emploi {
    int id;
    public emploi(){}
}
