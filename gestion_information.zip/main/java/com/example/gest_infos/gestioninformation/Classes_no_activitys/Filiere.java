package com.example.gest_infos.gestioninformation.Classes_no_activitys;

/**
 * Created by root on 11/22/17.
 */

public class Filiere {
    private String Filiere_ID;
    private String Filiere_Nom;


    public Filiere(String Filiere_Nom){

        this.Filiere_Nom=Filiere_Nom;

    }

    public String getFiliere_ID() {
        return Filiere_ID;
    }

    public String getFiliere_Nom() {
        return Filiere_Nom;
    }
}
