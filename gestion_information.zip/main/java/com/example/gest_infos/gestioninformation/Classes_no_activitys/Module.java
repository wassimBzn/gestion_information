package com.example.gest_infos.gestioninformation.Classes_no_activitys;

/**
 * Created by root on 1/13/18.
 */

public class Module {
    private  String id_module;
    private   String nom_module;
    public  Module(String id_module,String nom_module){
        this.id_module=id_module;
        this.nom_module=nom_module;
    }


    public String getId_module() {
        return id_module;
    }

    public String getNom_module() {
        return nom_module;
    }
}
