package com.example.gest_infos.gestioninformation.Classes_no_activitys;

/**
 * Created by root on 1/13/18.
 */

public class Note {
    private String DS;
    private String TP;
    private String NP;
    private String exam;
    private Matiere Matiere;
    private Module module;
    private double Moy;

    public Note(Module module,Matiere Matiere,String DS,String TP,
    String NP,String exam,double Moy){
        this.module=module;
        this.Matiere=Matiere;
        this.DS=DS;
        this.exam=exam;
        this.Moy=Moy;
        this.NP=NP;
        this.TP=TP;

    }


    public String getDS() {
        return DS;
    }

    public String getTP() {
        return TP;
    }

    public String getNP() {
        return NP;
    }

    public String getExam() {
        return exam;
    }

    public double getMoy() {
        return Moy;
    }

    public Matiere getMatiere() {
        return Matiere;
    }

    public Module getModule() {
        return module;
    }
}
