package com.example.gest_infos.gestioninformation.Classes_no_activitys;

/**
 * Created by root on 12/12/17.
 */

public class absance {
    private String id_Absance;
    private String Matiere;
    private String date_absance;
    private String id_Matiere;
      private  int Num_absance;

    public absance(String id_absance, String matiere, String date_absance, String id_matiere,int Num_absance) {
        this.id_Absance = id_absance;
        this.Matiere = matiere;
        this.date_absance = date_absance;
        this.id_Matiere = id_matiere;
        this.Num_absance=Num_absance;
    }

    public String getId_Absance() {
        return id_Absance;
    }

    public String getMatiere() {
        return Matiere;
    }

    public String getDate_absance() {
        return date_absance;
    }

    public String getId_Matiere() {
        return id_Matiere;
    }

    public int getNum_absance() {
        return Num_absance;
    }
}
